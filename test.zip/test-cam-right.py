import depthai as dai
import time
import logging

# V02 poprawiony blad wysylania, send tez musi byc w petli
# V03 dodane parametry script inputs blocking false i queue 1 (bo default jest true i 8)
# i to powodowalo po pewnym czasie duze lagi na transmisji
# v04 to socket na raz i dodane sendall
# v05 wysylanie liczby 0.1f zamiast 0.4f
# oraz zmiana na wypalanie wszyskich kamer na raz
# v06 dodane logowanie komunikacji i poprawiony blad sock/conn

# divide depth frame into segments
nH = 22 #21 #15
nV = 14 #14 #10

OAK_IP = "192.168.70.65"

# Setup logging
log_path = f"send_log_{OAK_IP.replace('.', '_')}.txt"
logging.basicConfig(filename=log_path, level=logging.INFO, format='%(asctime)s %(message)s')

Margin_T = 0.1 # T - top :: margines jaka czesc ekranu np. 0.5 polowa
Margin_B = 0.0 # B - bottom :: margines jaka czesc ekranu np. 0.5 polowa
Margin_L = 0.25 # L - left :: margines jaka czesc ekranu np. 0.5 polowa
Margin_R = 0.35 # R - right :: margines jaka czesc ekranu np. 0.5 polowa

# Start defining a pipeline
pipeline = dai.Pipeline()

monoLeft = pipeline.create(dai.node.MonoCamera)
monoRight = pipeline.create(dai.node.MonoCamera)
stereo = pipeline.create(dai.node.StereoDepth)
spatialLocationCalculator = pipeline.create(dai.node.SpatialLocationCalculator)

# Properties
monoLeft.setResolution(dai.MonoCameraProperties.SensorResolution.THE_400_P)
monoLeft.setCamera("left")
monoRight.setResolution(dai.MonoCameraProperties.SensorResolution.THE_400_P)
monoRight.setCamera("right")

stereo.setDefaultProfilePreset(dai.node.StereoDepth.PresetMode.DEFAULT)
stereo.setLeftRightCheck(True)
stereo.setSubpixel(True) # False
spatialLocationCalculator.inputConfig.setWaitForMessage(False)


rV = nV*1.0/(1.0-(Margin_T+Margin_B))
rH = nH*1.0/(1.0-(Margin_L+Margin_R))
for y in range(nV):
    for x in range(nH):
        #x = nH - (x+1)
        config = dai.SpatialLocationCalculatorConfigData()
        config.depthThresholds.lowerThreshold = 200
        config.depthThresholds.upperThreshold = 10000
        config.roi = dai.Rect(dai.Point2f(Margin_R + x/rH, Margin_T + y/rV), dai.Point2f(Margin_R + (x+1)/rH, Margin_T + (y+1)/rV))
        spatialLocationCalculator.initialConfig.addROI(config)
   
        
# Script node
script = pipeline.create(dai.node.Script)
script.setProcessor(dai.ProcessorType.LEON_CSS)

script.inputs['spat'].setBlocking(False)
script.inputs['spat'].setQueueSize(1)
spatialLocationCalculator.out.link(script.inputs['spat'])

script.setScript("""
import socket
import random
import time

# Create a function for logging
def log_send():
    node.warn("SEND")  # This will appear in device logs

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
server.bind(('0.0.0.0', 65432))
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)  # Allow reuse of address
server.listen(10)

while True:
    try:
        data = node.io['spat'].get()
        spatialData = data.getSpatialLocations()

        # Extract distances
        distances = []
        for depthData in spatialData:
            distance = depthData.spatialCoordinates.z / 1000  # Convert to meters
            distances.append(distance)
                        
        if len(distances) > 0: 
            
            det_arr = []
            for det in distances:
                det_arr.append(f"{det:.1f}")
            det_str = "|".join(det_arr)
            
            # node.warn(f"Waiting for client")
            try:
                conn, client = server.accept()
                # node.warn(f"Connected to client IP: {client}")

                with conn:
                    HLEN = 32
                    MESLEN = len(det_str)
                    header = f"HEAD {MESLEN}".ljust(HLEN)
                    # node.warn(f'>{header}<')
                    
                    # send header
                    msg = bytes(header, encoding='ascii')
                    log_send()  # Log the send operation
                    conn.sendall(msg)  # Use conn, not sock

                    # send data
                    msg = bytes(det_str, encoding='ascii')
                    conn.sendall(msg)  # Use conn, not sock
            except Exception as e:
                node.warn(f"Socket error: {str(e)}")
                time.sleep(0.1)  # Small pause before retrying
                
    except Exception as e:
        node.warn(f"Main loop error: {str(e)}")
        time.sleep(0.5)  # Pause before continuing
""")

# Connections
monoLeft.out.link(stereo.left)
monoRight.out.link(stereo.right)
stereo.depth.link(spatialLocationCalculator.inputDepth)

d_info = dai.DeviceInfo(OAK_IP)
# Connect to device with pipeline
with dai.Device(pipeline, d_info) as device:
    while not device.isClosed():
        time.sleep(1)
       
# !!!! ostatecznie jak będzie działać to można to wypalić na kamerze kodem poniżej
# wtedy trzeba zakomentować linie od 99 do 103 (te powyzej tego komentarza
        
# Flash the pipeline
# (f, bl) = dai.DeviceBootloader.getFirstAvailableDevice()
# bootloader = dai.DeviceBootloader(bl)
# progress = lambda p : print(f'Flashing progress: {p*100:.1f}%')
# bootloader.flash(progress, pipeline)

"""
#But for this example, we want to flash the device with the pipeline
device_infos = dai.DeviceBootloader.getAllAvailableDevices()
print(f'Found {len(device_infos)} devices')
print(device_infos)

for device in device_infos:
    print(f"Start flashing on device: {device}")
    bootloader = dai.DeviceBootloader(device)
    progress = lambda p : print(f'Flashing progress: {p*100:.1f}%')
    (r, errmsg) = bootloader.flash(progress, pipeline, compress=True, applicationName="Aura")
    #(r, errmsg) = bootloader.flash(progress, pipeline, compress=True, applicationName=SW_VERSION)
    if r: print("Flash OK")
    else: print("Flash ERROR:", errmsg)
"""